""" Viết chương trình Python in cây thông ra màn hình theo mẫu 
    *
    **
  *******
    ***
   *****
 ***********
    * *
    * *
"""
print("    *")
print("    **")
print("  *******")
print("    ***")
print("   *****")
print(" ***********")
print("    * *")
print("    * *")


