# Viết chương trình Python in câu'Chào các bạn!'ra màn hình
print('Chào các bạn!')