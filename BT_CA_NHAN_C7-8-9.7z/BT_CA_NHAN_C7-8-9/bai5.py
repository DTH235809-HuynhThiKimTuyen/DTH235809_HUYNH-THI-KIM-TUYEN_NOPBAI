# Viết chương trình in Họ và Tên của bạn ra màn hình,ví dụ " Nguyễn văn A"
ho=input('Nhập Họ:')
ten=input('Nhập Tên:')
print('Họ và Tên :',ho,ten)