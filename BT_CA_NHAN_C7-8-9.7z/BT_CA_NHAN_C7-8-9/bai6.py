print('Mình về mình có nhớ ta')
print('Mười lăm năm ấy thiết tha mặn nồng')
print('Mình về mình có nhớ không?')
print('Nhìn cây nhớ núi, nhìn sông nhớ nguồn')