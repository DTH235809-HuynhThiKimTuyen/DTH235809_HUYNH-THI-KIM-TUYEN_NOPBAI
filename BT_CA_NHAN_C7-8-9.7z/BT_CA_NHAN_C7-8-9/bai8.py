"""
xây dựng chương trình hiển thị ra màn hình như sau:
****
*  *
*  *
****
"""
print('****')
print('*  *')
print('*  *')
print('****')
