""" hãy in ra màn hình chữ nhật như dưới đây
*********
*********
*********
"""
# range( start, stop, step)
for i in range(4):
    print('*'*9)